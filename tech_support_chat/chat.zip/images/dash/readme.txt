"34aL volume 3.1" icons set

Ammount of icons:
60

Colors: 
Colored, grey

Icon Sizes:
24x24

File Types:
.ico (RGBA, 256 color, 16 color), 
.tiff (RGBA)
.gif (indexed)
.bmp (RGB - 1 color background), 
.png (RGBA)

Note: These icons are free for use.