<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">


    <title>Click 2 Call  Admin</title>
    <link rel="stylesheet" href="css/style.css">

    
    
  </head>

  <body style="margin:0px; padding:0px;background:#43B4E8;" oncontextmenu="return false">
  <?php  if (!isset($_POST["loginstep"])){ ?>
<div class="container" id="container" style="max-width:800px; height:100%">
<form class="form" action="#" method="POST">
		
			<input type="text" placeholder="Username" style="font-size:18px; width:320px" name="username" >
			<input type="password" placeholder="Password" style="font-size:18px; width:320px" name="password">
			
	
	
			<button type="submit" name="loginstep" id="login-button" ><span id="sendinfo">Send</span></button>
		</form>
</div>
<?php } else if (isset($_POST["loginstep"])){
	
	$username=$_POST["username"];
	$password=$_POST["password"];
	if ($username=="reception" && $password=="enter12345") {
		


?>
<iframe src="requests/requests.php" width="100%" height="1024" frameborder="0" scrolling="auto" style="z-index:9999999;"></iframe>
<?php
	}
	else {
		?>
		<div class="container" id="container" style="max-width:800px; height:100%">
<form class="form" action="#" method="POST">
		
			<input type="text" placeholder="Username" style="font-size:18px; width:320px" name="username" >
			<input type="password" placeholder="Password" style="font-size:18px; width:320px" name="password">
			
	
	
			<button type="submit" name="loginstep" id="login-button" ><span id="sendinfo">Send</span></button>
		</form>
</div>
		<?php
	}
}
?>
  </body>
</html>
