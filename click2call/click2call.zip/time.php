<?php
echo "Localhost time : " . date("h:i:sa");
echo "<br> hour : ";
echo date("h");
if (date("h")<=05){
	echo " -- Not 5 oclock yet.";
}else {
	echo " 5 oclock reached.";
}
echo "<hr>";
echo "UK time : ";
$date = date("h:i:sa");
$newdate = strtotime ( '-2 hour' , strtotime ( $date ) ) ;
$newdate1 = date ( "h:i:sa" , $newdate );
echo $newdate1;
echo "<br> hour : ";
$newdate2 = date ( "h" , $newdate );
echo $newdate2;
if (date("h")<=05){
	echo " -- Not 5 oclock yet.";
}
else {
	echo " 5 oclock reached.";
}
?>