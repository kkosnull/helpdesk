<?php

for ($i=0; $i<=100000000; $i++){
$con = mysql_connect("db38.grserver.gr", "acheron", "dignusestentrare@@01");
// $con = mysql_connect("db13.grserver.gr", $this->user, $this->password);
				if (!$con)
				  {
				  die('Could not connect: ' . mysql_error());
				  }
				  else
				  {
					 
					 mysql_select_db("click2call", $con);
					 
					 $sql = "SET NAMES 'utf8'";
					mysql_query($sql, $con);
					
					$sql="SELECT * FROM `click2call`.`requests` WHERE `active` = 1";
						
						echo $_SESSION['requests_number'];
						$result=mysql_query($sql, $con);
						
					$num_rows = mysql_num_rows($result);
					echo $num_rows;
					
						
				  }
}
?>