<?php

$db="auto";
$user="root";
$password="";

$db="click2call";
$user="acheron";
$password="dignusestentrare@@01";					
										
					
?>
